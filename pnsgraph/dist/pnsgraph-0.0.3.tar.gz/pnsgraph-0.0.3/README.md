# P-graph for Process Network Synthesis (PNS)

Early version of P-graph for PNS. 

Contains Python implementation of algorithms (Maximal Structure Generation, Solution Structure Generation) in P-graph
import setuptools

setuptools.setup(
    name='pnsgraph',
    version='0.0.1',
    packages=setuptools.find_packages(),
    url='',
    license='',
    author='jftapia',
    author_email='',
    description=''
)